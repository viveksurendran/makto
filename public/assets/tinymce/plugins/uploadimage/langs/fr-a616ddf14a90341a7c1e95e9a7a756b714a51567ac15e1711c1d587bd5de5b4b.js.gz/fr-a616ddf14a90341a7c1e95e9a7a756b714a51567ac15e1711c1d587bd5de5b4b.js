tinyMCE.addI18n('fr', {
  'Insert an image from your computer': "Envoyer une image de votre ordinateur",
  'Insert image': "Insérer une image",
  'Choose an image': "Choisissez une image",
  'You must choose a file': "Vous devez sélectionner un fichier",
  'Got a bad response from the server': "Le serveur a envoyé une réponse erronée",
  "Didn't get a response from the server": "Le serveur n'a pas renvoyé de réponse",
  'Insert': "Insérer",
  'Cancel': "Annuler",
  'Image description': "Description de l'image",
});
