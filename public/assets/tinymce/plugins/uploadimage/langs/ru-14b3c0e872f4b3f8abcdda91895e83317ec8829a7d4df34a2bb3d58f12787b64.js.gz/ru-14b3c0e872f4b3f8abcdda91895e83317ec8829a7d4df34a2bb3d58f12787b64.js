tinyMCE.addI18n('ru', {
  'Insert an image from your computer': 'Вставить изображение с вашего компьютера',
  'Insert image': "Вставить изображение",
  'Choose an image': "Изображение",
  'You must choose a file': "Необходимо выбрать файл",
  'Got a bad response from the server': "Получен некорректный ответ с сервера",
  "Didn't get a response from the server": "Не получен ответ с сервера",
  'Insert': "Вставить",
  'Cancel': "Отмена",
  'Image description': "Информация",
});
